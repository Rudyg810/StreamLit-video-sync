import streamlit as st
import moviepy.editor as mp
from moviepy.editor import VideoFileClip, AudioFileClip
from google.cloud import speech
import os
from pydub import AudioSegment
import io
import openai
import requests
from google.cloud import texttospeech
import json
from utilities.index import Utilities
from utilities.google_services import GoogleServices
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "key.json"
client = speech.SpeechClient()

def main():
    st.title("Video Transcription and Correction App")

    video_file = st.file_uploader("Upload a video file", type=["mp4"])
    
    if video_file:
        video_path = "temp_video.mp4"
        with open(video_path, "wb") as f:
            f.write(video_file.read())
        
        st.write("Video uploaded successfully.")

        transcription_map = Utilities.create_audio_transcription_map(video_path)

        st.write("Original 10-Second Transcription Map:")
        for time_range, transcription in transcription_map.items():
            st.write(f"{time_range}: {transcription}")

        corrected_transcription_map = Utilities.correct_transcription_map(transcription_map)

        st.write("Corrected 10-Second Transcription Map:")
        for time_range, corrected_transcription in corrected_transcription_map.items():
            st.write(f"{time_range}: {corrected_transcription}")

        st.write("Generating audio files for each time range...")
        Utilities.generate_audio_files_from_map(corrected_transcription_map)

        st.write("Audio generation complete! Joining the audio files into one...")

        final_audio_path = "final_output.wav"
        Utilities.join_audio_files_from_map(corrected_transcription_map, output_file=final_audio_path)

        st.write("All audio files joined successfully! Attaching the audio to the video...")

        original_video_name = video_file.name.split('.')[0]
        output_video_path = f"out_{original_video_name}.mp4"

        Utilities.attach_audio_to_video(video_path, final_audio_path, output_video_path)

        st.write(f"Final video with attached audio saved as {output_video_path}.")
        os.remove(video_path)
        os.remove(final_audio_path)


if __name__ == "__main__":
    main()

